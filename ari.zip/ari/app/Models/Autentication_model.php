<?php

namespace App\Models;

use CodeIgniter\Model;

class Barang_model extends Model {
    protected $table = 'user';
}