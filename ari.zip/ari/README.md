# Uas Pemrograman 6 Codeigniter UMBANTEN 2022

# Persyaratan

- [XAMP](https://www.apachefriends.org/download.html)
- [COMPOSER](https://getcomposer.org/)
- [VSCODE](https://code.visualstudio.com/)

# Instalasi

Clone atau download repositori ini

```
git clone https://github.com/Anggasayogo/uas_perog_6_ci.git
```

install dependesi terlebih dahulu menggunakan perintah

```
composer install
```

```
create db dan import db yang sudah dilampirkan di root project
```

lalu untuk mencobanya kamu bisa menjalankan

```
php spark serve
```

atau kamu bisa taroh project ini ke htdocs xampp kamu lalu kamu akses url : http://localhost/namaproject


@anggamaulana20222